﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;

namespace ConsoleGame
{
    internal class Main
    {
        private Program program = new Program();

        /// <summary>The connection</summary>
        private readonly MySqlConnection Conn = new MySqlConnection("server=localhost;user id=root;password=1234; persistsecurityinfo=True;database=dat602_assessmentdb_m2");

        private static readonly int[] _game = Enumerable.Range(1, 100).ToArray();

        private string[,] grid = {
                    {"[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]"},
                    {"[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]"},
                    {"[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]"},
                    {"[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]"},
                    {"[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]"},
                    {"[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]"},
                    {"[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]"},
                    {"[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]"},
                    {"[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]"},
                    {"[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]"}
                };

        private readonly int[] Game = _game;

        public int Score { get; set; } = 0;
        public int GameNumber { get; set; }
        public string UserType { get; set; }
        public string UpdateUser { get; set; }
        public string[] UserString { get; set; }
        public int PreviousPosition { get; set; } = 1;
        public int? NewPosition { get; set; } = null;
        public int row;
        public int col;
        public int index = 0;
        /*  __  __           _             __  __          _     _                   _
           |  \/  |   __ _  (_)  _ __     |  \/  |   ___  | |_  | |__     ___     __| |  ___
           | |\/| |  / _` | | | | '_ \    | |\/| |  / _ \ | __| | '_ \   / _ \   / _` | / __|
           | |  | | | (_| | | | | | | |   | |  | | |  __/ | |_  | | | | | (_) | | (_| | \__ \
           |_|  |_|  \__,_| |_| |_| |_|   |_|  |_|  \___|  \__| |_| |_|  \___/   \__,_| |___/
                                                                                             */

        /// <summary>Opens the main menu.</summary>
        public void OpenMainMenu()
        {
            Display.DrawMainMenu();
            string option;
            option = Console.ReadLine();

            switch (option)
            {
                case "1":
                    CheckLoginDetailsDataAccess(program.Player.User, program.Player.Password);
                    break;

                case "2":
                    SignUpDataAccess(program.Player.User, program.Player.Password, program.Player.Email);
                    break;

                case "3":
                    System.Environment.Exit(1);
                    break;

                default:
                    Console.WriteLine("Invalid Option!");
                    Console.ReadLine();
                    OpenMainMenu();
                    break;
            }
        }

        /// <summary>Opens the user menu.</summary>
        public void OpenUserMenu()
        {
            Display.DrawUserMenu();
            string option;
            option = Console.ReadLine();

            switch (option)
            {
                case "1":
                    OpenLeaderboardDataAccess();
                    break;

                case "2":
                    OpenGameLobby();
                    break;

                case "3":
                    LogoutDataAccess(program.Player.User);
                    Console.Clear();
                    OpenMainMenu();
                    break;
            }
        }

        /// <summary>Opens the admin menu.</summary>
        public void OpenAdminMenu()
        {
            Display.DrawAdminMenu();
            string option;
            option = Console.ReadLine();

            switch (option)
            {
                case "1":
                    Console.Clear();
                    OpenSettingsMenu();
                    break;

                case "2":
                    Console.Clear();
                    OpenGameLobby();
                    break;

                case "3":
                    OpenLeaderboardDataAccess();
                    break;

                case "4":
                    Console.Clear();
                    LogoutDataAccess(program.Player.User);
                    OpenMainMenu();
                    break;
            }
        }

        /// <summary>Prints the leaderboard data.</summary>
        /// <param name="read">The read.</param>
        private void PrintLeaderboardData(MySqlDataReader read)
        {
            while (read.Read())
            {
                if (read.IsDBNull(read.GetOrdinal("Username"))
                    || read.IsDBNull(read.GetOrdinal("Total Score"))
                    || read.IsDBNull(read.GetOrdinal("Games Played"))
                    || read.IsDBNull(read.GetOrdinal("Average Score")))
                {
                    continue;
                }
                else
                {
                    Console.WriteLine(
                        $"=================\n" +
                        $"Username: {read.GetString("Username")}, " +
                        $"Total Score: {read.GetString("Total Score")}, " +
                        $"Games Played: {read.GetString("Games Played")}, " +
                        $"Average Score: {read.GetString("Average Score")}\n" +
                        $"=================");
                }
            }
            read.Close();
        }

        /// <summary>Displays the leaderboard options.</summary>
        private void DrawLeaderboardOptions()
        {
            Console.WriteLine("\n Press 1 to return to the home screen");
            var value = Console.ReadLine();

            if (value == "1")
            {
                Console.Clear();
                OpenUserMenu();
            }
            else
            {
                Console.WriteLine("Please select a correct option");
                Console.ReadLine();
                OpenLeaderboardDataAccess();
            }
        }

        /// <summary>Opens the settings menu.</summary>
        public void OpenSettingsMenu()
        {
            Display.DrawAdminSettings();
            string option;
            option = Console.ReadLine();

            switch (option)
            {
                case "1":
                    Console.Clear();
                    SettingsGameNumberListDataAccess();
                    break;

                case "2":
                    Console.Clear();
                    SettingsUsernameListDataAccess();
                    break;

                case "3":
                    Console.Clear();
                    AdminCreateUserValidation();
                    break;

                case "4":
                    Console.Clear();
                    OpenAdminMenu();
                    break;
            }
        }

        /// <summary>Validation for the inputss when an admin creates a user</summary>
        private void AdminCreateUserValidation()
        {
            Display.DrawAddNewUser();
            string input = Console.ReadLine();
            string[] splitArr = input.Split(',');
            UserString = splitArr;
            List<string> strList = new List<string>();
            foreach (string str in splitArr)
            {
                strList.Add(str);
            }

            switch (UserString[0])
            {
                case "Exit":
                case "exit":
                    Conn.Close();
                    Console.Clear();
                    OpenSettingsMenu();
                    break;

                default:
                    if (UserString.Length != 4)
                    {
                        Display.DrawInvalidInputValue();
                        AdminCreateUserValidation();
                    }
                    else if (UserString[3] != "1" && UserString[3] != "0")
                    {
                        Display.DrawAdminBoolError();
                        AdminCreateUserValidation();
                    }
                    else
                    {
                        if (CheckUsernameDataAccess(UserString[0]))
                        {
                            Display.DrawExistingUserError();
                            AdminCreateUserValidation();
                        }
                        else
                        {
                            AdminCreateUserDataAccess();
                            Display.DrawAdminCreateUser();
                            OpenSettingsMenu();
                        }
                    }
                    break;
            }
        }

        /// <summary>Writes a list of usernames in the database</summary>
        /// <param name="reader">The reader.</param>
        public void WriteUsernames(MySqlDataReader reader)
        {
            while (reader.Read())
            {
                Console.WriteLine(reader.GetString("username"));
            }
            reader.Close();
        }

        /// <summary> Checks the selected value from the list and validates it </summary>
        public void UsernameListSelectedVal()
        {
            Display.DrawPlayerListOptions();

            string option;
            option = Console.ReadLine();
            UpdateUser = option;

            if (option == "exit")
            {
                Conn.Close();
                Console.Clear();
                Conn.Close();
                OpenSettingsMenu();
            }
            else
            {
                if (CheckUsernameDataAccess(UpdateUser))
                {
                    UserSettingsOptions();
                }
                else
                {
                    Conn.Close();
                    Console.WriteLine($"User {option} does not exist, please enter a valid name");
                    Console.ReadLine();
                    SettingsUsernameListDataAccess();
                }
            }
        }

        /// <summary>Writes a list of game numbers from the database</summary>
        /// <param name="reader">The reader.</param>
        public void WriteGameNumbers(MySqlDataReader reader)
        {
            while (reader.Read())
            {
                Console.WriteLine(reader.GetString("gameNumber"));
            }
            reader.Close();
        }

        /// <summary>Checks the inputted game value and validates its integrity</summary>
        public void GameNumberListSelectedVal()
        {
            Console.WriteLine("======== \n");
            Console.WriteLine("Please type in the game number that you would like to modify");
            Console.WriteLine("or type \"exit\" to return to the settings form");
            Console.WriteLine("======== \n");
            Regex regex = new Regex("/[0-9]/");
            string option;
            option = Console.ReadLine();
            if (option == "exit" || option == "Exit")
            {
                Conn.Close();
                Console.Clear();
                Conn.Close();
                OpenSettingsMenu();
            }
            else if (!regex.IsMatch(option))
            {
                Console.WriteLine("Please Enter A Correct Value...");
                Console.ReadLine();
                Console.Clear();
                SettingsGameNumberListDataAccess();
            }
            else
            {
                GameNumber = int.Parse(option);
                if (CheckGameExistsDataAccess(GameNumber))
                {
                    OpenGamesOptions();
                }
                else
                {
                    Conn.Close();
                    Console.WriteLine($"Game Number {option} does not exist, please enter a valid game number.");
                    Console.ReadLine();
                    SettingsGameNumberListDataAccess();
                }
            }
        }

        /// <summary>Displays the users settings options</summary>
        public void UserSettingsOptions()
        {
            try
            {
                Console.Clear();
                Console.WriteLine($"User Page: {UpdateUser}");
                Console.WriteLine("============= \n\n");

                Display.DrawUserSettingsOptions();

                string optionPlayer;
                optionPlayer = Console.ReadLine();

                switch (optionPlayer)
                {
                    case "1":
                        Console.Clear();
                        Console.WriteLine($"User Page: {UpdateUser}");
                        Console.WriteLine("============= \n\n");
                        Conn.Close();
                        LoadUserInfoDataAccess();

                        break;

                    case "2":
                        DeleteUserDataAccess();
                        Conn.Close();
                        break;

                    case "3":
                        SetPlayerStatusDataAccess();
                        Console.Clear();
                        Conn.Close();
                        UserSettingsOptions();
                        break;

                    case "4":
                        Console.Clear();
                        Conn.Close();
                        SettingsUsernameListDataAccess();
                        break;
                }
            }
            catch (Exception error)
            {
                Console.WriteLine(error);
            }
        }

        /// <summary>Displays the games settings options</summary>
        public void OpenGamesOptions()
        {
            Console.Clear();
            Console.WriteLine(" Here are your options");
            Console.WriteLine("======================");
            Console.WriteLine("=   Delete Game: 1   =");
            Console.WriteLine("=   Reset Game : 2   =");
            Console.WriteLine("=   Exit       : 3   =");
            Console.WriteLine("======================");
            Console.WriteLine("   Select an option  ");
            string option;
            option = Console.ReadLine();

            switch (option)
            {
                case "1":
                    Conn.Close();
                    Console.Clear();
                    DeleteGameDataAccess();
                    Console.WriteLine("Game Deleted successfully");
                    Console.ReadLine();
                    Console.Clear();
                    OpenSettingsMenu();
                    break;

                case "2":
                    Conn.Close();
                    Console.Clear();
                    ResetGameDataAccess();
                    Console.WriteLine("Game reset successful");
                    Console.ReadLine();
                    Console.Clear();
                    OpenSettingsMenu();
                    break;

                case "3":
                    Conn.Close();
                    Console.Clear();
                    OpenSettingsMenu();
                    break;
            }
        }

        /// <summary>Displays the game lobby options</summary>
        public void OpenGameLobby()
        {
            Console.Clear();
            Console.WriteLine("Welcome to the Game Menu \n\n");
            Console.WriteLine("Here are your options");
            Console.WriteLine("=====================");
            Console.WriteLine("=  Create Game: 1   =");
            Console.WriteLine("=  Join Game  : 2   =");
            Console.WriteLine("=  Leave Menu : 3   =");
            Console.WriteLine("=====================");
            Console.WriteLine("  Select an option   ");

            string option;
            option = Console.ReadLine();
            Console.Clear();
            switch (option)
            {
                case "1":
                    try
                    {
                        CreateNewGame();
                        grid[0, 0] = "[X]";
                        ExecuteGamePlay(1, 0);
                    }
                    catch (Exception error)
                    {
                        Console.WriteLine(error);
                        Console.ReadLine();
                    }
                    break;

                case "2":
                    LoadGameOptionsDataAccess();
                    break;

                case "3":
                    Console.Clear();
                    if (UserType == "Admin")
                    {
                        OpenAdminMenu();
                    }
                    else
                    {
                        OpenUserMenu();
                    }
                    break;
            }
        }

        /// <summary>Displays the options when choosing a game to join</summary>
        private void GameOptionsChoices()
        {
            Console.WriteLine("========");
            Console.WriteLine("Please type in the game number that you would like to join");
            Console.WriteLine("or type \"exit\" to return to the settings form");
            Console.WriteLine("======== \n");

            Regex reg = new Regex("^(0|[1-9][0-9]*)$");
            string num;
            num = Console.ReadLine();
            if (num == "exit" || num == "Exit")
            {
                Console.Clear();
                if (UserType == "Admin")
                {
                    OpenAdminMenu();
                }
                else
                {
                    OpenUserMenu();
                }
            }
            else if (num == "" || !reg.IsMatch(num) || !CheckGameExistsDataAccess(int.Parse(num)))
            {
                Conn.Close();
                Console.WriteLine($"Game {num} does not exist. Please select a valid game number");
                Console.ReadLine();
                Console.Clear();
                OpenGameLobby();
            }
            else
            {
                GameNumber = int.Parse(num);
                SetGameNumberDataAccess(int.Parse(num));
            }
        }

        /// <summary>Calls the required methods for creating a game</summary>
        public void CreateNewGame()
        {
            try
            {
                row = 0;
                col = 0;
                index = 0;
                SetCharacterTypeDataAccess(program.Player.Character, program.Player.User);
                InsertGameDataDataAccess(program.Player.GameMode, program.Player.User);
                GetPlayerGameNumberDataAccess();
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
                Console.ReadLine();
                return;
            }
        }

        /// <summary>Calls the required methods for joining an existing game</summary>
        public void JoinExisitingGame()
        {
            SetCharacterTypeDataAccess(program.Player.Character, program.Player.User);
            Console.Clear();
            Console.WriteLine($"{NewPosition.Value}, {PreviousPosition}");
            Console.ReadLine();
            index = NewPosition.Value - 1;
            grid[row, col] = "[X]";
            ExecuteGamePlay(NewPosition.Value, PreviousPosition);
        }

        /// <summary>Draws the grid into the console each time it is called</summary>
        public void DrawBoardArray()
        {
            for (int i = 0; i < grid.GetLength(0); i++)
            {
                for (int j = 0; j < grid.GetLength(1); j++)
                {
                    Console.Write(grid[i, j]);
                }
                Console.WriteLine();
            }
        }

        /// <summary>Runs the game. This allows a user to input movements and update the database</summary>
        public void ExecuteGamePlay(int next, int prev)
        {
            try
            {
                while (true)
                {
                    Console.Clear();
                    PrintWelcome();

                    DrawBoardArray();

                    string[] flat = grid.Cast<string>().ToArray();
                    var arr = Enumerable.Range(0, 100).Where(i => flat[i] == "[$]").ToArray();

                    UpdatePlayerPositionDataAccess(1, 0);

                    for (var i = index; i < Game.Length; i++)
                    {
                        ConsoleKey keyPressed;
                        do
                        {
                            ConsoleKeyInfo keyInfo = Console.ReadKey(true);
                            keyPressed = keyInfo.Key;

                            switch (keyPressed)
                            {
                                case ConsoleKey.UpArrow:
                                    row--;
                                    if (i - 10 < 0 || row < 0)
                                    {
                                        row++;
                                        Console.WriteLine("You cant move here");
                                    }
                                    else
                                    {
                                        PrintWelcome();
                                        PreviousPosition = Game[i];
                                        i -= 10;
                                        NewPosition = Game[i];

                                        if (IsTileValidDataAccess((int)NewPosition, GameNumber))
                                        {
                                            UpdatePlayerPositionDataAccess((int)NewPosition, PreviousPosition);

                                            if (grid[row, col] == "[$]")
                                            {
                                                Console.WriteLine("Wow");
                                                Console.ReadLine();
                                            }

                                            grid[row, col] = "[X]";
                                            grid[row + 1, col] = "[ ]";
                                            DrawBoardArray();

                                            Console.WriteLine();
                                            Console.WriteLine("==================================");
                                            Console.WriteLine($"Your new position is: {NewPosition}");
                                            Console.WriteLine($"Your old position is: {PreviousPosition}");
                                            Console.WriteLine("==================================");
                                            Console.WriteLine();
                                            Console.WriteLine("Press escape to exit");
                                        }
                                        else
                                        {
                                            Console.WriteLine("You cant move here");
                                            i += 10;
                                            NewPosition = Game[i];

                                            grid[row, col] = "[X]";
                                            grid[row + 1, col] = "[ ]";

                                            DrawBoardArray();
                                            PrintPosition();
                                        }
                                    }
                                    break;

                                case ConsoleKey.LeftArrow:
                                    col--;
                                    if (i == 0 || col < 0)
                                    {
                                        col++;
                                        Console.WriteLine("You cant move here");
                                    }
                                    else
                                    {
                                        PrintWelcome();
                                        PreviousPosition = Game[i];
                                        i--;
                                        NewPosition = Game[i];

                                        if (IsTileValidDataAccess((int)NewPosition, GameNumber))
                                        {
                                            UpdatePlayerPositionDataAccess((int)NewPosition, PreviousPosition);

                                            grid[row, col] = "[X]";
                                            grid[row, col + 1] = "[ ]";
                                            DrawBoardArray();

                                            Console.WriteLine();
                                            Console.WriteLine("==================================");
                                            Console.WriteLine($"Your new position is: {NewPosition}");
                                            Console.WriteLine($"Your old position is: {PreviousPosition}");
                                            Console.WriteLine("==================================");
                                            Console.WriteLine();
                                            Console.WriteLine("Press escape to exit");
                                        }
                                        else
                                        {
                                            Console.WriteLine("You cant move here");
                                            i++;
                                            NewPosition = Game[i];

                                            grid[row, col] = "[X]";
                                            grid[row + 1, col] = "[ ]";

                                            DrawBoardArray();
                                            PrintPosition();
                                        }
                                    }
                                    break;

                                case ConsoleKey.DownArrow:
                                    row++;
                                    if (i + 10 > Game.Length || row == 10)
                                    {
                                        row--;
                                        NewPosition = Game[i];
                                        Console.WriteLine("You cant move here");
                                    }
                                    else
                                    {
                                        PrintWelcome();
                                        PreviousPosition = Game[i];
                                        i += 10;
                                        NewPosition = Game[i];

                                        if (IsTileValidDataAccess((int)NewPosition, GameNumber))
                                        {
                                            UpdatePlayerPositionDataAccess((int)NewPosition, PreviousPosition);
                                            if (NewPosition == 100)
                                            {
                                                try
                                                {
                                                    try
                                                    {
                                                        UpdatePlayerPositionDataAccess((int)NewPosition, PreviousPosition);
                                                        grid[row, col] = "[ ]";
                                                        grid[row - 1, col] = "[ ]";
                                                    }
                                                    catch (Exception error)
                                                    {
                                                        Console.WriteLine(error);
                                                        Console.ReadLine();
                                                    }
                                                    Console.Clear();
                                                    Console.WriteLine("Congrats, you have finished the game");
                                                    Console.WriteLine("Press enter to continue");
                                                    Console.ReadLine();
                                                    try
                                                    {
                                                        OpenGameLobby();
                                                    }
                                                    catch (Exception error)
                                                    {
                                                        Console.WriteLine(error);
                                                        Console.ReadLine();
                                                    }
                                                }
                                                catch (Exception error)
                                                {
                                                    Console.WriteLine(error);
                                                    Console.ReadLine();
                                                }
                                            }
                                            else
                                            {
                                                grid[row, col] = "[X]";
                                                grid[row - 1, col] = "[ ]";
                                                DrawBoardArray();
                                                PrintPosition();
                                            }
                                        }
                                        else
                                        {
                                            Console.WriteLine("You cant move here");
                                            Console.ReadLine();
                                            i -= 10;
                                            NewPosition = Game[i];

                                            grid[row, col] = "[X]";
                                            grid[row + 1, col] = "[ ]";

                                            DrawBoardArray();
                                            PrintPosition();
                                        }
                                    }
                                    break;

                                case ConsoleKey.RightArrow:
                                    col++;
                                    if (i == Game.Length - 1 || col == 10)
                                    {
                                        col--;
                                        Console.WriteLine("You cant move here");
                                    }
                                    else
                                    {
                                        PrintWelcome();
                                        PreviousPosition = Game[i];
                                        i++;
                                        NewPosition = Game[i];
                                        if (IsTileValidDataAccess((int)NewPosition, GameNumber))
                                        {
                                            UpdatePlayerPositionDataAccess((int)NewPosition, PreviousPosition);

                                            if (NewPosition == 100)
                                            {
                                                try
                                                {
                                                    UpdatePlayerPositionDataAccess((int)NewPosition, PreviousPosition);
                                                    grid[row, col] = "[ ]";
                                                    grid[row, col - 1] = "[ ]";
                                                }
                                                catch (Exception error)
                                                {
                                                    Console.WriteLine(error);
                                                    Console.ReadLine();
                                                }
                                                //UpdatePlayerPosition((int)NewPosition, PreviousPosition);
                                                Console.Clear();
                                                Console.WriteLine("Congrats, you have finished the game");
                                                Console.WriteLine("Press enter to continue");
                                                Console.ReadLine();
                                                try
                                                {
                                                    OpenGameLobby();
                                                }
                                                catch (Exception error)
                                                {
                                                    Console.WriteLine(error);
                                                    Console.ReadLine();
                                                }
                                            }
                                            else
                                            {
                                                grid[row, col] = "[X]";
                                                grid[row, col - 1] = "[ ]";
                                                DrawBoardArray();

                                                Console.WriteLine();
                                                Console.WriteLine("==================================");
                                                Console.WriteLine($"Your new position is: {NewPosition}");
                                                Console.WriteLine($"Your old position is: {PreviousPosition}");
                                                Console.WriteLine("==================================");
                                                Console.WriteLine();
                                                Console.WriteLine("Press escape to exit");
                                            }
                                        }
                                        else
                                        {
                                            Console.WriteLine("You cant move here");
                                            i--;
                                            NewPosition = Game[i];

                                            grid[row, col] = "[X]";
                                            grid[row + 1, col] = "[ ]";

                                            DrawBoardArray();
                                            PrintPosition();
                                        }
                                    }
                                    break;

                                case ConsoleKey.Escape:
                                    Console.Clear();
                                    Conn.Close();
                                    try
                                    {
                                        var pos = Enumerable.Range(0, 100).Where(x => flat[x] == "[X]").ToArray();

                                        NewPosition = Game[i];
                                        SavePlayerPositionDataAccess(program.Player.User, NewPosition.Value, GameNumber);


                                        for (int l = 0; l < grid.GetLength(0); l++)
                                        {
                                            for (int j = 0; j < grid.GetLength(1); j++)
                                            {
                                                grid[l, j] = "[ ]";
                                            }
                                            Console.WriteLine();
                                        }
                                    }
                                    catch (Exception error)
                                    {
                                        Console.WriteLine(error);
                                        Console.ReadLine();
                                    }

                                    OpenGameLobby();
                                    break;
                            }
                        } while (keyPressed != ConsoleKey.Enter);
                    }
                }

            }
            catch (Exception error)
            {
                Console.WriteLine(error);
                Console.ReadLine();
            }
        }

        /// <summary>Prints the current and previous position of the player</summary>
        private void PrintPosition()
        {
            Console.WriteLine();
            Console.WriteLine("==================================");
            Console.WriteLine($"Your new position is: {NewPosition}");
            Console.WriteLine($"Your old position is: {PreviousPosition}");
            Console.WriteLine("==================================");
            Console.WriteLine();
            Console.WriteLine("Press escape to exit");
        }

        /// <summary>Prints the header for the game</summary>
        private void PrintWelcome()
        {
            Console.Clear();
            Console.WriteLine("==================================");
            Console.WriteLine($"Welcome to the Dungeon");
            Console.WriteLine("==================================");
        }

        /// <summary>All of the input validation for the sign up process and the confirmation if the data meets the requirements</summary>
        /// <param name="cmd">The command.</param>
        /// <param name="username">The username.</param>
        /// <param name="password">The password.</param>
        /// <param name="email">The email.</param>
        private void SignUpExceptions(MySqlCommand cmd, string username, string password, string email)
        {
            if (program.Player.User != "" && password != "" && email != "")
            {
                if (CheckUsernameDataAccess(username))
                {
                    Console.Clear();
                    Console.WriteLine("This Username Already Exists, Press Enter to try logging in");
                    Console.ReadLine();
                    CheckLoginDetailsDataAccess(username, password);
                }
                else
                {
                    Conn.Open();
                    if (cmd.ExecuteNonQuery() == 1)
                    {
                        Conn.Close();
                        Console.WriteLine("Error");
                        Console.ReadLine();
                    }
                    else
                    {
                        Conn.Close();
                        Console.Clear();
                        SetUserLoginStatusDataAccess(username);
                        OpenUserMenu();
                    }
                }
            }
            else
            {
                Conn.Close();
                Console.WriteLine("Please Enter all your details");
                Console.ReadLine();
                OpenMainMenu();
            }
        }

        /// <summary>All of the login exceptions and the confirmation if the data matches a record in the database.</summary>
        /// <param name="username">The username.</param>
        /// <param name="password">The password.</param>
        /// <param name="table">The table.</param>
        private void LoginExceptions(string username, string password, DataTable table)
        {
            if (program.Player.User != "" || password != "")
            {
                if (table.Rows.Count > 0)
                {
                    try
                    {
                        Console.Clear();

                        Conn.Close();
                        if (CheckAccountStatusDataAccess(program.Player.User))
                        {
                            Conn.Close();
                            Console.WriteLine("Account is locked. To unlock account, please contact an admin at daniel-ewers2@live.nmit.ac.nz \n");
                            Console.WriteLine("Press Enter to Continue...");
                            Console.ReadLine();
                            OpenMainMenu();
                            return;
                        }
                        else
                        {
                            if (!CheckIfAdminDataAccess(username))
                            {
                                Conn.Close();
                                UserType = "Admin";
                                SetUserLoginStatusDataAccess(username);
                                OpenAdminMenu();
                                Console.ReadLine();
                            }
                            else if (CheckIfAdminDataAccess(username))
                            {
                                Conn.Close();
                                UserType = "User";
                                SetUserLoginStatusDataAccess(username);
                                Console.Clear();
                                OpenUserMenu();
                                Console.ReadLine();
                            }
                            else
                            {
                                Conn.Close();
                                Console.WriteLine("Critical Error");
                            }
                        }
                    }
                    catch (Exception error)
                    {
                        Conn.Close();
                        Console.WriteLine(error.Message);
                    }
                }
                else
                {
                    Conn.Close();
                    Console.Clear();
                    Console.WriteLine("Username or Password is incorrect!");
                    Console.WriteLine("Press Enter to Continue");
                    Console.ReadLine();
                    SetFailedAttemptDataAccess(program.Player.User);
                    OpenMainMenu();
                }
            }
            else
            {
                Conn.Close();
                Console.WriteLine("Please Enter all your details");
                Console.ReadLine();
                OpenMainMenu();
            }
        }

        /// <summary>Prints the details for when the admin wants to create or update a users information</summary>
        private void ReadInputData()
        {
            Console.WriteLine("======================================================\n");
            Console.WriteLine("Here are your options:\n");
            Console.WriteLine("Type new and/or existing user details to update user:\n");
            Console.WriteLine("Format must follow:\n");
            Console.WriteLine("Password, Email, Admin Priv, Account Status... Without spaces and each value seperated by a comma\n");
            Console.WriteLine("Admin Priv and Account Status must be a bool value\n");
            Console.WriteLine("For example: xxx,xxx,0,0\n\n");
            Console.WriteLine("Type \"Exit\" to return to user: list\n");

            string input = Console.ReadLine();

            string[] splitArr = input.Split(',');

            UserString = splitArr;

            List<string> strList = new List<string>();
            foreach (string str in splitArr)
            {
                strList.Add(str);
            }

            switch (UserString[0])
            {
                case "Exit":
                case "exit":
                    Conn.Close();
                    Console.Clear();
                    UserSettingsOptions();
                    break;

                default:
                    if (UserString.Length != 4)
                    {
                        Conn.Close();
                        Console.WriteLine("Please Enter Details! \n");
                        Console.WriteLine("Press Enter to continue");
                        Console.ReadLine();
                        LoadUserInfoDataAccess();
                    }
                    else if (UserString[2] != "0" && UserString[2] != "1" && UserString[3] != "0" && UserString[3] != "1")
                    {
                        Conn.Close();
                        Console.WriteLine("Admin Priv and Account Status must be a bool value! \n");
                        Console.WriteLine("Press Enter to continue");
                        Console.ReadLine();
                        LoadUserInfoDataAccess();
                    }
                    else
                    {
                        Conn.Close();
                        UpdateUserInfoDataAccess();
                    }

                    break;
            }
        }

        /* ____            _                  _
          |  _ \    __ _  | |_    __ _       / \      ___    ___    ___   ___   ___
          | | | |  / _` | | __|  / _` |     / _ \    / __|  / __|  / _ \ / __| / __|
          | |_| | | (_| | | |_  | (_| |    / ___ \  | (__  | (__  |  __/ \__ \ \__ \
          |____/   \__,_|  \__|  \__,_|   /_/   \_\  \___|  \___|  \___| |___/ |___/
                                                                                    */

        /// <summary>Data access for `GetDataLeaderboard` Stored Procedure</summary>
        public void OpenLeaderboardDataAccess()
        {
            Conn.Close();
            Console.Clear();
            Console.WriteLine("Leaderboard \n\n");
            Console.SetWindowPosition(0, 0);
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("GetDataLeaderboard", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    Conn.Open();
                    MySqlDataReader read = cmd.ExecuteReader();
                    PrintLeaderboardData(read);
                    Conn.Close();

                    DrawLeaderboardOptions();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        /// <summary>Data access for `GetPlayerUsernames` Stored Procedure</summary>
        public void SettingsUsernameListDataAccess()
        {
            Conn.Close();
            try
            {
                Display.DrawPlayerList();
                using (MySqlCommand cmd = new MySqlCommand("GetPlayerUsernames", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    Conn.Open();
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        WriteUsernames(reader);
                    }
                    Conn.Close();
                    UsernameListSelectedVal();
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
                Console.ReadLine();
            }
        }

        /// <summary>Data access for `GetGameNumbers` Stored Procedure</summary>
        public void SettingsGameNumberListDataAccess()
        {
            Conn.Close();
            Display.DrawGameNumberHeader();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("GetGameNumbers", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    Conn.Open();
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        WriteGameNumbers(reader);
                    }
                    Conn.Close();

                    GameNumberListSelectedVal();
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
                Console.ReadLine();
            }
        }

        /// <summary>Data access for `LoadData` Stored Procedure</summary>
        private void LoadUserInfoDataAccess()
        {
            Conn.Close();
            try
            {
                using (MySqlCommand command = new MySqlCommand("LoadData", Conn))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    MySqlParameter mySqlParameter = command.Parameters.AddWithValue("uname", UpdateUser);
                    using (MySqlDataReader read = command.ExecuteReader())
                    {
                        try
                        {
                            Conn.Open();
                            read.Read(); //reads the first single returned row.
                            Console.WriteLine("======================================================\n");
                            Console.WriteLine(
                                "Users Password is: " + (string)read["user_password"] + "\n" +
                                "Users email is: " + (string)read["user_email"] + "\n" +
                                "User Admin type is: " + (bool)read["user_isAdmin"] + "\n" +
                                "User Account status is: " + (bool)read["user_accountStatus"] + "\n");
                            read.Close();
                            Conn.Close();

                            ReadInputData();
                        }
                        catch (Exception error)
                        {
                            Console.WriteLine(error);
                        }
                    }
                }
            }
            catch (Exception error)
            {
                Console.WriteLine(error);
            }
        }

        /// <summary>Data access for `UpdateUser` Stored Procedure</summary>
        public void UpdateUserInfoDataAccess()
        {
            Conn.Close();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("UpdateUser", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    MySqlParameter mySqlParameter1 = cmd.Parameters.AddWithValue("uname", UpdateUser);
                    MySqlParameter mySqlParameter2 = cmd.Parameters.AddWithValue("pwd", UserString[0]);
                    MySqlParameter mySqlParameter3 = cmd.Parameters.AddWithValue("email", UserString[1]);
                    MySqlParameter mySqlParameter4 = cmd.Parameters.AddWithValue("priv", UserString[2]);
                    MySqlParameter mySqlParameter5 = cmd.Parameters.AddWithValue("acc", UserString[3]);

                    using (MySqlDataAdapter adapter = new MySqlDataAdapter())
                    {
                        adapter.SelectCommand = cmd;

                        using (DataTable table = new DataTable())
                        {
                            try
                            {
                                Conn.Open();
                                adapter.Fill(table);
                                Conn.Close();

                                Console.WriteLine("User updated successfully");
                                Console.ReadLine();
                                Console.Clear();
                                UserSettingsOptions();
                            }
                            catch (Exception error)
                            {
                                Conn.Close();
                                Console.WriteLine(error);
                            }
                        }
                    }
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
            }
        }

        /// <summary>Data access for `AdminDeleteUser` Stored Procedure</summary>
        public void DeleteUserDataAccess()
        {
            Conn.Close();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("AdminDeleteUser", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@uname", UpdateUser);
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter())
                    {
                        adapter.SelectCommand = cmd;
                        using (DataTable table = new DataTable())
                        {
                            try
                            {
                                Conn.Open();
                                adapter.Fill(table);
                                Conn.Close();

                                Console.WriteLine("User Deleted successfully");
                                Console.ReadLine();
                                Console.Clear();
                                OpenSettingsMenu();
                            }
                            catch (Exception error)
                            {
                                Console.WriteLine(error);
                            }
                        }
                    }
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
            }
        }

        /// <summary>Data access for `AdminResetPlayer` Stored Procedure</summary>
        public void SetPlayerStatusDataAccess()
        {
            Conn.Close();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("AdminAccountStatus", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    MySqlParameter mySqlParameter = cmd.Parameters.AddWithValue("uname", UpdateUser);
                    try
                    {
                        Conn.Open();
                        cmd.ExecuteNonQuery();
                        Conn.Close();
                    }
                    catch (Exception error)
                    {
                        Conn.Close();
                        Console.WriteLine(error);
                    }
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
            }
        }

        /// <summary>Data access for `AdminDeleteGame` Stored Procedure</summary>
        public void DeleteGameDataAccess()
        {
            Conn.Close();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("AdminDeleteGame", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    MySqlParameter mySqlParameter = cmd.Parameters.AddWithValue("game", GameNumber);
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter())
                    {
                        adapter.SelectCommand = cmd;
                        using (DataTable table = new DataTable())
                        {
                            try
                            {
                                Conn.Open();
                                adapter.Fill(table);
                                Conn.Close();
                            }
                            catch (Exception error)
                            {
                                Conn.Close();
                                Console.WriteLine(error);
                                Console.ReadLine();
                            }
                        }
                    }
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
            }
        }

        /// <summary>Data access for `ResetGame` Stored Procedure</summary>
        public void ResetGameDataAccess()
        {
            Conn.Close();
            using (MySqlCommand cmd = new MySqlCommand("ResetGame", Conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                MySqlParameter mySqlParameter1 = cmd.Parameters.AddWithValue("num", GameNumber);
                try
                {
                    Conn.Open();
                    cmd.ExecuteNonQuery();
                    Conn.Close();
                    Console.WriteLine("Game Reset Successfully...");
                    Console.ReadLine();
                    OpenSettingsMenu();
                }
                catch (Exception Error)
                {
                    Conn.Close();
                    Console.WriteLine(Error);
                }
            }
        }

        /// <summary>Data access for `GetGameNumbers` Stored Procedure</summary>
        private void LoadGameOptionsDataAccess()
        {
            Conn.Close();
            try
            {
                Conn.Open();
                using (MySqlDataReader reader = new MySqlCommand("GetGameNumbers", Conn)
                {
                    CommandType = CommandType.StoredProcedure
                }.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine(reader.GetString("gameNumber"));
                    }

                    reader.Close();
                    Conn.Close();
                    GameOptionsChoices();
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
                Console.ReadLine();
            }
        }

        /// <summary>Data access for `SetGameNumber` Stored Procedure</summary>
        private void SetGameNumberDataAccess(int num)
        {
            Conn.Close();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("SetGameNumber", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    MySqlParameter mySqlParameter1 = cmd.Parameters.AddWithValue("num", num);
                    MySqlParameter mySqlParameter2 = cmd.Parameters.AddWithValue("uname", program.Player.User);

                    Conn.Open();
                    cmd.ExecuteNonQuery();
                    Conn.Close();
                    JoinExisitingGame();
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
                Console.ReadLine();
            }
        }

        /// <summary>Data access for `GetGameNumber` Stored Procedure</summary>
        private bool GetPlayerGameNumberDataAccess()
        {
            Conn.Close();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("GetGameNumber", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    MySqlParameter mySqlParameter = cmd.Parameters.AddWithValue("uname", program.Player.User);

                    using (MySqlDataAdapter adapter = new MySqlDataAdapter())
                    {
                        adapter.SelectCommand = cmd;
                        using (DataTable table = new DataTable())
                        {
                            Conn.Open();
                            adapter.Fill(table);
                            Conn.Close();

                            for (Int32 i = 0; i < table.Rows.Count; i++)
                            {
                                GameNumber = int.Parse(table.Rows[i][0].ToString());
                            }
                            return table.Rows.Count > 0;
                        }
                    }
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
                return false;
            }
        }

        /// <summary>Data access for `ExitGame` Stored Procedure</summary>
        private void SavePlayerPositionDataAccess(string username, int postion, int gameNumber)
        {
            Conn.Close();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("ExitGame", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    MySqlParameter mySqlParameter1 = cmd.Parameters.AddWithValue("uname", username);
                    MySqlParameter mySqlParameter2 = cmd.Parameters.AddWithValue("currentTile", postion);
                    MySqlParameter mySqlParameter3 = cmd.Parameters.AddWithValue("num", gameNumber);

                    Conn.Open();
                    cmd.ExecuteNonQuery();
                    Conn.Close();
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
                Console.ReadLine();
            }
        }

        /// <summary>Data access for `CheckValid` Stored Procedure</summary>
        public bool IsTileValidDataAccess(int tile, int game)
        {
            Conn.Close();
            using (MySqlCommand cmd = new MySqlCommand("CheckValid", Conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("tileVal", tile);
                cmd.Parameters.AddWithValue("num", game);
                Conn.Open();
                using (MySqlDataReader read = cmd.ExecuteReader())
                {
                    while (read.Read())
                    {
                        if (read[0] != DBNull.Value)
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    }
                    read.Close();
                }
                Conn.Close();
            }
            return false;
        }

        /// <summary>Data access for `UpdatePlayerTile` Stored Procedure</summary>
        public void UpdatePlayerPositionDataAccess(int index, int last)
        {
            Conn.Close();
            using (MySqlCommand cmd = new MySqlCommand("UpdatePlayerTile", Conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("uname", program.Player.User);
                cmd.Parameters.AddWithValue("tileVal", index);
                cmd.Parameters.AddWithValue("lastValue", last);
                cmd.Parameters.AddWithValue("score", Score);
                cmd.Parameters.AddWithValue("num", GameNumber);

                try
                {
                    Conn.Open();
                    cmd.ExecuteNonQuery();
                    Conn.Close();
                }
                catch (Exception error)
                {
                    Conn.Close();
                    Console.WriteLine(error);
                    Console.ReadLine();
                }
            }
        }

        /// <summary>Data access for `Logout` Stored Procedure</summary>
        public void LogoutDataAccess(string username)
        {
            Conn.Close();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("Logout", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    MySqlParameter mySqlParameter = cmd.Parameters.AddWithValue("uname", username);
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter())
                    {
                        adapter.SelectCommand = cmd;
                        using (DataTable table = new DataTable())
                        {
                            Conn.Open();
                            adapter.Fill(table);
                            Conn.Close();
                        }
                    }
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
                Console.ReadLine();
            }
        }

        /// <summary>Data access for `createPlayer` Stored Procedure</summary>
        public void SignUpDataAccess(string username, string password, string email)
        {
            Conn.Close();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("CreateUserAccount", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    MySqlParameter mySqlParameter1 = cmd.Parameters.AddWithValue("uname", username);
                    MySqlParameter mySqlParameter2 = cmd.Parameters.AddWithValue("pwd", password);
                    MySqlParameter mySqlParameter3 = cmd.Parameters.AddWithValue("email", email);

                    SignUpExceptions(cmd, username, password, email);
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
                Console.ReadLine();
            }
        }

        /// <summary>Data access for `SetLoggedIn` Stored Procedure</summary>
        public void SetUserLoginStatusDataAccess(string username)
        {
            Conn.Close();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("SetLoggedIn", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    MySqlParameter mySqlParameter = cmd.Parameters.AddWithValue("uname", username);
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter())
                    {
                        adapter.SelectCommand = cmd;
                        using (DataTable table = new DataTable())
                        {
                            Conn.Open();
                            adapter.Fill(table);
                            Conn.Close();
                        }
                    }
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
                Console.WriteLine();
            }
        }

        /// <summary>Data access for `CheckInfo` Stored Procedure</summary>
        public void CheckLoginDetailsDataAccess(string username, string password)
        {
            Conn.Close();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("CheckInfo", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    MySqlParameter mySqlParameter1 = cmd.Parameters.AddWithValue("uname", username);
                    MySqlParameter mySqlParameter2 = cmd.Parameters.AddWithValue("pwd", password);

                    using (MySqlDataAdapter adapter = new MySqlDataAdapter())
                    {
                        adapter.SelectCommand = cmd;

                        using (DataTable table = new DataTable())
                        {
                            Conn.Open();
                            adapter.Fill(table);
                            Conn.Close();
                            LoginExceptions(username, password, table);
                        }
                    }
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error.Message);
                Console.ReadLine();
            }
        }

        /// <summary>Data access for `FailedAttempt` Stored Procedure</summary>
        public void SetFailedAttemptDataAccess(string username)
        {
            Conn.Close();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("FailedAttempt", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    MySqlParameter mySqlParameter = cmd.Parameters.AddWithValue("uname", username);
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter())
                    {
                        adapter.SelectCommand = cmd;
                        using (DataTable table = new DataTable())
                        {
                            Conn.Open();
                            adapter.Fill(table);
                            Conn.Close();
                        }
                    }
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error.Message);
                Console.ReadLine();
            }
        }

        /// <summary>Data access for `checkUsernameSignUp` Stored Procedure</summary>
        public bool CheckUsernameDataAccess(string username)
        {
            Conn.Close();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("checkUsernameSignUp", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    MySqlParameter mySqlParameter = cmd.Parameters.AddWithValue("uname", username);

                    using (MySqlDataAdapter adapter = new MySqlDataAdapter())
                    {
                        adapter.SelectCommand = cmd;
                        using (DataTable table = new DataTable())
                        {
                            Conn.Open();
                            adapter.Fill(table);
                            Conn.Close();
                            return table.Rows.Count > 0;
                        }
                    }
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
                Console.ReadLine();
                return false;
            }
        }

        /// <summary>Data access for `CheckGameNum` Stored Procedure</summary>
        public bool CheckGameExistsDataAccess(int gameNumber)
        {
            Conn.Close();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("CheckGameNum", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    MySqlParameter mySqlParameter = cmd.Parameters.AddWithValue("@gameNum", gameNumber);
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter())
                    {
                        adapter.SelectCommand = cmd;
                        using (DataTable table = new DataTable())
                        {
                            Conn.Open();
                            adapter.Fill(table);
                            Conn.Close();
                            return table.Rows.Count > 0;
                        }
                    }
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
                Console.ReadLine();
                return false;
            }
        }

        /// <summary>Data access for `AccountStatus` Stored Procedure</summary>
        public Boolean CheckAccountStatusDataAccess(string username)
        {
            Conn.Close();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("AccountStatus", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    MySqlParameter mySqlParameter = cmd.Parameters.AddWithValue("uname", username);
                    Conn.Open();
                    bool isLocked = (bool)cmd.ExecuteScalar();
                    Conn.Close();
                    return isLocked;
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
                Console.ReadLine();
                return false;
            }
        }

        /// <summary>Data access for `CheckIfAdmin` Stored Procedure</summary>
        public Boolean CheckIfAdminDataAccess(string username)
        {
            Conn.Close();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("CheckIfAdmin", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    MySqlParameter mySqlParameter = cmd.Parameters.AddWithValue("uname", username);
                    Conn.Open();
                    bool isAdmin = (bool)cmd.ExecuteScalar();
                    Conn.Close();
                    return !isAdmin;
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
                Console.ReadLine();
                return false;
            }
        }

        /// <summary>Data access for `InsertGameData` Stored Procedure</summary>
        private void InsertGameDataDataAccess(string gamemode, string username)
        {
            Conn.Close();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("InsertGameData", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    MySqlParameter mySqlParameter1 = cmd.Parameters.AddWithValue("gameMode", gamemode);
                    MySqlParameter mySqlParameter2 = cmd.Parameters.AddWithValue("uname", username);

                    Conn.Open();
                    cmd.ExecuteNonQuery();
                    Conn.Close();
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
                Console.ReadLine();
            }
        }

        /// <summary>Data access for `SetCharacterType` Stored Procedure</summary>
        private void SetCharacterTypeDataAccess(string character, string username)
        {
            Conn.Close();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("SetCharacterType", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    MySqlParameter mySqlParameter1 = cmd.Parameters.AddWithValue("charType", character);
                    MySqlParameter mySqlParameter2 = cmd.Parameters.AddWithValue("uname", username);

                    Conn.Open();
                    cmd.ExecuteNonQuery();
                    Conn.Close();
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
                Console.ReadLine();
            }
        }

        /// <summary>Data access for `AdminCreateUser` Stored Procedure</summary>
        private void AdminCreateUserDataAccess()
        {
            Conn.Close();
            try
            {
                using (MySqlCommand cmd = new MySqlCommand("AdminCreateUser", Conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    MySqlParameter mySqlParameter1 = cmd.Parameters.AddWithValue("uname", UserString[0]);
                    MySqlParameter mySqlParameter2 = cmd.Parameters.AddWithValue("pwd", UserString[1]);
                    MySqlParameter mySqlParameter3 = cmd.Parameters.AddWithValue("email", UserString[2]);
                    MySqlParameter mySqlParameter4 = cmd.Parameters.AddWithValue("priv", UserString[3]);

                    using (MySqlDataAdapter adapter = new MySqlDataAdapter())
                    {
                        adapter.SelectCommand = cmd;

                        using (DataTable table = new DataTable())
                        {
                            Conn.Open();
                            adapter.Fill(table);
                            Conn.Close();
                        }
                    }
                }
            }
            catch (Exception error)
            {
                Conn.Close();
                Console.WriteLine(error);
                Console.ReadLine();
            }
        }
    }
}