﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleGame
{
    class Display
    {
        public static Program game = new Program();

        public static void DrawMainMenu()
        {
            Console.Clear();
            Console.WriteLine("Welcome to my Game!!!");
            Console.WriteLine();
            Console.WriteLine("Here are your options");
            Console.WriteLine("=====================");
            Console.WriteLine("=   Login   : 1     =");
            Console.WriteLine("=   Sign up : 2     =");
            Console.WriteLine("=   Exit    : 3     =");
            Console.WriteLine("=====================");
            Console.WriteLine("  Select an option   ");
        }

        public static void DrawUserMenu()
        {
            Console.WriteLine($"Welcome user: {game.Player.User} \n\n");
            Console.WriteLine("Here are your options");
            Console.WriteLine("=====================");
            Console.WriteLine("=  Leaderboard: 1   =");
            Console.WriteLine("=  Game Menu  : 2   =");
            Console.WriteLine("=  Log out    : 3   =");
            Console.WriteLine("=====================");
            Console.WriteLine("  Select an option   ");
        }

        public static void DrawAdminMenu()
        {
            Console.WriteLine($"Welcome Admin: {game.Player.User} \n\n");
            Console.WriteLine("Here are your options");
            Console.WriteLine("=====================");
            Console.WriteLine("=   Settings :  1   =");
            Console.WriteLine("=   Game Menu:  2   =");
            Console.WriteLine("=  Leaderboard: 3   =");
            Console.WriteLine("=   Log out  :  4   =");
            Console.WriteLine("=====================");
            Console.WriteLine("  Select an option  ");
        }

        public static void DrawAdminSettings()
        {
            Console.Clear();
            Console.WriteLine(" Here are your options");
            Console.WriteLine("======================");
            Console.WriteLine("= Game Controls  : 1 =");
            Console.WriteLine("= Player Controls: 2 =");
            Console.WriteLine("= Add User       : 3 =");
            Console.WriteLine("= Return to menu : 4 =");
            Console.WriteLine("======================");
            Console.WriteLine("   Select an option  ");
        }

        public static void DrawAddNewUser()
        {
            Console.WriteLine("Create User:\n");
            Console.WriteLine("======================================================\n");
            Console.WriteLine("Here are your options:\n");
            Console.WriteLine("Type new a user details to create a user:\n");
            Console.WriteLine("Format must follow:\n");
            Console.WriteLine("Username, Password, Email, Admin Priv... Without spaces and each value seperated by a comma\n");
            Console.WriteLine("For example: xxx,xxx,xxx,0\n\n");
            Console.WriteLine("Type \"Exit\" to return to settings\n");
        }

        public static void DrawInvalidInputValue()
        {
            Console.WriteLine("Please Enter Correct Number of Details! \n");
            Console.WriteLine("Press Enter to continue");
            Console.ReadLine();
            Console.Clear();
        }

        public static void DrawAdminBoolError()
        {
            Console.WriteLine("Admin Priv must be a bool value! \n");
            Console.WriteLine("Press Enter to continue");
            Console.ReadLine();
            Console.Clear();
        }

        public static void DrawExistingUserError()
        {
            Console.Clear();
            Console.WriteLine("This Username Already Exists, Please Enter a new one!");
            Console.WriteLine("Press Enter to continue");
            Console.ReadLine();
            Console.Clear();
        }

        public static void DrawAdminCreateUser()
        {
            Console.WriteLine("User created successfully...");
            Console.ReadLine();
            Console.Clear();
        }

        public static void DrawPlayerList()
        {
            Console.Clear();
            Console.WriteLine(" Player List \n\n");
            Console.WriteLine("Usernames");
            Console.WriteLine("========");
        }

        public static void DrawPlayerListOptions()
        {
            Console.WriteLine("======== \n");
            Console.WriteLine("Please type in the user's usermame that you would like to modify");
            Console.WriteLine("or type \"exit\" to return to the settings form");
            Console.WriteLine("======== \n");
        }

        public static void DrawGameNumberHeader()
        {
            Console.Clear();
            Console.WriteLine("Games\n");
            Console.WriteLine("========\n\n");
            Console.WriteLine("Game Number");
            Console.WriteLine("========");
        }

        public static void DrawUserSettingsOptions()
        {
            Console.WriteLine(" Here are your options");
            Console.WriteLine("======================");
            Console.WriteLine("= Update Player  : 1 =");
            Console.WriteLine("= Delete Player  : 2 =");
            Console.WriteLine("= Set User Status: 3 =");
            Console.WriteLine("= Return to menu : 4 =");
            Console.WriteLine("======================");
            Console.WriteLine("   Select an option  ");
        }
    }
}
