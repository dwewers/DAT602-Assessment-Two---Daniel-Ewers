using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace ConsoleGame
{
    public class Program
    {
        private static Main data = new Main();

        //=======================================================
        //Test Data
        //=======================================================

        //Username, password,    email,   gamemode,  character
        //public UserData Player = new UserData("daniel", "123", "email123", "Classic", "Wizard");
        public UserData Player = new UserData("daniel", "123", "email123", "Classic", "Wizard");

        /// <summary>Gets or sets the data.</summary>
        /// <value>The data.</value>
        internal static Main Data { get => data; set => data = value; }

        /// <summary>Defines the entry point of the application.</summary>
        /// <param name="args">The arguments.</param>
        private static void Main(string[] args)
        {
            try
            {
                Data.OpenMainMenu();
            }
            catch (Exception error)
            {
                Console.WriteLine(error);
                Console.ReadLine();
            }
        }
    }
}