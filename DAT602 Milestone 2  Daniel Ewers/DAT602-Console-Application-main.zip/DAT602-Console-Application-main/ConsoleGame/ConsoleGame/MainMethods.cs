﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace ConsoleGame
{
    public class MainMethods
    {
        private DataAccess access = new DataAccess();
        private Display dsp = new Display();

        public string username { get; set; }
        public string password { get; set; }
        public string email { get; set; }
        public string character { get; set; }
        public string gamemode { get; set; }

        private string[,] grid = {
                    {"[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]"},
                    {"[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]"},
                    {"[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]"},
                    {"[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]"},
                    {"[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]"},
                    {"[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]"},
                    {"[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]"},
                    {"[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]"},
                    {"[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]"},
                    {"[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]", "[ ]"}
                };

        private static readonly int[] _game = Enumerable.Range(1, 100).ToArray();

        private readonly int[] Game = _game;

        public void OpenMainMenu()
        {
            dsp.DrawMainMenu();
            string option;
            option = Console.ReadLine();

            switch (option)
            {
                case "1":
                    try
                    {
                        access.Login(username, password);
                    }
                    catch (Exception error)
                    {
                        Console.WriteLine(error);
                        Console.ReadLine();
                    }

                    break;

                case "2":
                    access.SignUp(username, password, email);
                    break;

                case "3":
                    System.Environment.Exit(1);
                    break;

                default:
                    Console.WriteLine("Invalid Option!");
                    Console.ReadLine();
                    OpenMainMenu();
                    break;
            }
        } //No

        public void OpenUserMenu()
        {
            dsp.DrawUserMenu();
            string option;
            option = Console.ReadLine();

            switch (option)
            {
                case "1":
                    access.Leaderboard();
                    break;

                case "2":
                    OpenGameLobby();
                    break;

                case "3":
                    access.Logout(username);
                    Console.Clear();
                    OpenMainMenu();
                    break;
            }
        } //No

        public void OpenAdminMenu()
        {
            dsp.DrawAdminMenu();
            string option;
            option = Console.ReadLine();

            switch (option)
            {
                case "1":
                    Console.Clear();
                    OpenSettingsMenu();
                    break;

                case "2":
                    Console.Clear();
                    OpenGameLobby();
                    break;

                case "3":
                    Console.Clear();
                    access.Logout(username);
                    OpenMainMenu();
                    break;
            }
        } //No

        public void OpenSettingsMenu()
        {
            dsp.DrawAdminSettings();
            string option;
            option = Console.ReadLine();

            switch (option)
            {
                case "1":

                    Console.Clear();
                    OpenGameList();
                    break;

                case "2":

                    Console.Clear();
                    access.OpenUserList();
                    break;

                case "3":

                    Console.Clear();
                    AddNewUser();
                    break;

                case "4":

                    Console.Clear();
                    OpenAdminMenu();
                    break;
            }
        } //No

        public void AddNewUser()
        {
            dsp.DrawAddNewUser();
            string input = Console.ReadLine();
            string[] splitArr = input.Split(',');
            access.UserString = splitArr;
            List<string> strList = new List<string>();
            foreach (string str in splitArr)
            {
                strList.Add(str);
            }

            switch (access.UserString[0])
            {
                case "Exit":
                case "exit":

                    Console.Clear();
                    OpenSettingsMenu();
                    break;

                default:
                    if (access.UserString.Length != 4)
                    {
                        try
                        {
                            dsp.DrawInvalidInputValue();
                            AddNewUser();
                        }
                        catch (Exception error)
                        {
                            Console.WriteLine(error);
                            Console.ReadLine();
                        }
                    }
                    else if (access.UserString[3] != "1" && access.UserString[3] != "0")
                    {
                        try
                        {
                            dsp.DrawAdminBoolError();
                            AddNewUser();
                        }
                        catch (Exception error)
                        {
                            Console.WriteLine(error);
                            Console.ReadLine();
                        }
                    }
                    else
                    {
                        try
                        {
                            if (access.CheckUsername(access.UserString[0]))
                            {
                                try
                                {
                                    dsp.DrawExistingUserError();
                                    AddNewUser();
                                }
                                catch (Exception error)
                                {
                                    Console.WriteLine(error);
                                    Console.ReadLine();
                                }
                            }
                            else
                            {
                                try
                                {
                                    access.AdminAddNewUser();
                                    dsp.DrawAdminCreateUser();
                                    OpenSettingsMenu();
                                }
                                catch (Exception error)
                                {
                                    Console.WriteLine(error);
                                    Console.ReadLine();
                                }
                            }
                        }
                        catch (Exception error)
                        {
                            Console.WriteLine(error);
                            Console.ReadLine();
                        }
                    }
                    break;
            }
        } //No

        public void GetUserListOptions()
        {
            dsp.DrawPlayerListOptions();

            string option;
            option = Console.ReadLine();
            access.UpdateUser = option;

            if (option == "exit")
            {
                Console.Clear();

                OpenSettingsMenu();
            }
            else
            {
                if (access.CheckUsername(access.UpdateUser))
                {
                    OpenUserOptions();
                }
                else
                {
                    Console.WriteLine($"User {option} does not exist, please enter a valid name");
                    Console.ReadLine();
                    access.OpenUserList();
                }
            }
        } //No

        public void OpenGameList()
        {
            Console.Clear();
            Console.WriteLine("Games\n");
            Console.WriteLine("========\n\n");
            Console.WriteLine("Game Number");
            Console.WriteLine("========");
            access.LoadGameData();
        } //No

        public void ShowGameEditOptions()
        {
            Console.WriteLine("======== \n");
            Console.WriteLine("Please type in the game number that you would like to modify");
            Console.WriteLine("or type \"exit\" to return to the settings form");
            Console.WriteLine("======== \n");

            string option;
            option = Console.ReadLine();
            access.GameNumber = int.Parse(option);
            if (option == "exit")
            {
                Console.Clear();

                OpenSettingsMenu();
            }
            else
            {
                if (access.CheckGameExists(access.GameNumber.ToString()))
                {
                    OpenGamesOptions();
                }
                else
                {
                    Console.WriteLine($"Game Number {option} does not exist, please enter a valid game number.");
                    Console.ReadLine();
                    OpenGameList();
                }
            }
        } //No

        public void OpenUserOptions()
        {
            Console.Clear();
            Console.WriteLine($"User Page: {access.UpdateUser}");
            Console.WriteLine("============= \n\n");

            Console.WriteLine(" Here are your options");
            Console.WriteLine("======================");
            Console.WriteLine("= Update Player  : 1 =");
            Console.WriteLine("= Delete Player  : 2 =");
            Console.WriteLine("= Reset  Player  : 3 =");
            Console.WriteLine("= Return to menu : 4 =");
            Console.WriteLine("======================");
            Console.WriteLine("   Select an option  ");

            string optionPlayer;
            optionPlayer = Console.ReadLine();

            switch (optionPlayer)
            {
                case "1":
                    Console.Clear();
                    Console.WriteLine($"User Page: {access.UpdateUser}");
                    Console.WriteLine("============= \n\n");

                    access.LoadUserData();

                    break;

                case "2":
                    access.DeleteUser();

                    break;

                case "3":
                    access.ResetPlayerScore();
                    Console.Clear();

                    access.OpenUserList();
                    break;

                case "4":
                    Console.Clear();

                    access.OpenUserList();
                    break;
            }
        } //No

        public void OpenGameLobby()
        {
            Console.Clear();
            Console.WriteLine("Welcome to the Game Menu \n\n");
            Console.WriteLine("Here are your options");
            Console.WriteLine("=====================");
            Console.WriteLine("=  Create Game: 1   =");
            Console.WriteLine("=  Join Game  : 2   =");
            Console.WriteLine("=  Leave Menu : 3   =");
            Console.WriteLine("=====================");
            Console.WriteLine("  Select an option   ");

            string option;
            option = Console.ReadLine();

            switch (option)
            {
                case "1":
                    try
                    {
                        ExecuteGamePlay();
                    }
                    catch (Exception error)
                    {
                        Console.WriteLine(error);
                        Console.ReadLine();
                    }
                    break;

                case "2":
                    access.LoadGameOptions();
                    break;

                case "3":
                    Console.Clear();
                    if (access.UserType == "Admin")
                    {
                        OpenAdminMenu();
                    }
                    else
                    {
                        OpenUserMenu();
                    }
                    break;
            }
        } //No

        public void WriteGameData(MySqlDataReader reader)
        {
            while (reader.Read())
            {
                Console.WriteLine(reader.GetString("gameNumber"));
            }
        } //No

        public void PrintOptions()
        {
            Console.WriteLine("======== \n");
            Console.WriteLine("Please type in the game number that you would like to join");
            Console.WriteLine("or type \"exit\" to return to the settings form");
            Console.WriteLine("======== \n");

            string num;
            num = Console.ReadLine();
            if (num == "exit" || num == "Exit")
            {
                Console.Clear();
                if (access.UserType == "Admin")
                {
                    OpenAdminMenu();
                }
                else
                {
                    OpenUserMenu();
                }
            }
            else if (!access.CheckGameExists(num))
            {
                Console.WriteLine($"Game {num} does not exist. Please select a valid game number");
                Console.ReadLine();
                Console.Clear();
                OpenGameLobby();
            }
            else
            {
                access.SetGameNumber(num);
            }
        } //No

        public void OpenGamesOptions()
        {
            Console.Clear();
            Console.WriteLine(" Here are your options");
            Console.WriteLine("======================");
            Console.WriteLine("=   Delete Game: 1   =");
            Console.WriteLine("=   Reset Game : 2   =");
            Console.WriteLine("=   Exit       : 3   =");
            Console.WriteLine("======================");
            Console.WriteLine("   Select an option  ");
            string option;
            option = Console.ReadLine();

            switch (option)
            {
                case "1":

                    Console.Clear();
                    access.DeleteGame();
                    Console.WriteLine("Game Deleted successfully");
                    Console.ReadLine();
                    Console.Clear();
                    OpenSettingsMenu();
                    break;

                case "2":

                    Console.Clear();
                    access.ResetGame();
                    Console.WriteLine("Game reset successful");
                    Console.ReadLine();
                    Console.Clear();
                    OpenSettingsMenu();
                    break;

                case "3":

                    Console.Clear();
                    OpenSettingsMenu();
                    break;
            }
        } //No

        public void LoadData(MySqlDataReader read)
        {
            try
            {
                read.Read(); //reads the first single returned row.
                Console.WriteLine("======================================================\n");
                Console.WriteLine(
                    "Users Password is: " + (string)read["user_password"] + "\n" +
                    "Users email is: " + (string)read["user_email"] + "\n" +
                    "User Admin type is: " + (bool)read["user_isAdmin"] + "\n" +
                    "User Account status is: " + (bool)read["user_accountStatus"] + "\n");
                Console.WriteLine("======================================================\n");
                Console.WriteLine("Here are your options:\n");
                Console.WriteLine("Type new and/or existing user details to update user:\n");
                Console.WriteLine("Format must follow:\n");
                Console.WriteLine("Password, Email, Admin Priv, Account Status... Without spaces and each value seperated by a comma\n");
                Console.WriteLine("Admin Priv and Account Status must be a bool value\n");
                Console.WriteLine("For example: xxx,xxx,0,0\n\n");
                Console.WriteLine("Type \"Exit\" to return to user: list\n");
                read.Close();

                string input = Console.ReadLine();

                string[] splitArr = input.Split(',');

                access.UserString = splitArr;

                List<string> strList = new List<string>();

                foreach (string str in splitArr)
                {
                    strList.Add(str);
                }

                switch (access.UserString[0])
                {
                    case "Exit":
                    case "exit":

                        Console.Clear();
                        OpenUserOptions();
                        break;

                    default:
                        if (access.UserString.Length != 4)
                        {
                            Console.WriteLine("Please Enter Details! \n");
                            Console.WriteLine("Press Enter to continue");
                            Console.ReadLine();
                            access.LoadUserData();
                        }
                        else if (access.UserString[2] != "0" && access.UserString[2] != "1" && access.UserString[3] != "0" && access.UserString[3] != "1")
                        {
                            Console.WriteLine("Admin Priv and Account Status must be a bool value! \n");
                            Console.WriteLine("Press Enter to continue");
                            Console.ReadLine();
                            access.LoadUserData();
                        }
                        else
                        {
                            access.UpdateUserData();
                        }

                        break;
                }
            }
            catch (Exception error)
            {
                Console.WriteLine(error);
            }
        } //No

        public void PrintUsernames(MySqlDataReader reader)
        {
            while (reader.Read())
            {
                Console.WriteLine(reader.GetString("username"));
            }
        } //No

        public void CreateNewGame()
        {
            try
            {
                access.SetCharacterType(character, username);
                access.InsertGameData(gamemode, username);
                access.GetPlayerGameNumber();
            }
            catch (Exception error)
            {
                Console.WriteLine(error);
                Console.ReadLine();
                return;
            }
        } //No

        public void JoinExisitingGame()
        {
            access.SetCharacterType(character, username);
            Console.Clear();
            Console.WriteLine($"Welcome back to the Dungeon {username}");
            Console.WriteLine("Here are your options");
            Console.WriteLine("=====================");
            Console.WriteLine("=    Run Game : 1   =");
            Console.WriteLine("=    Exit Game: 2   =");
            Console.WriteLine("=====================");
            Console.WriteLine("  Select an option   ");
            string option;
            option = Console.ReadLine();

            switch (option)
            {
                case "1":
                    ExecuteGamePlay();
                    break;

                case "2":
                    Console.Clear();

                    break;
            }
        } //No

        public void DrawBoardArray()
        {
            for (int i = 0; i < grid.GetLength(0); i++)
            {
                for (int j = 0; j < grid.GetLength(1); j++)
                {
                    Console.Write(grid[i, j]);
                }
                Console.WriteLine();
            }
        } //No

        public void ExecuteGamePlay()
        {
            try
            {
                Console.Clear();
                Console.WriteLine("Press up, down, left, or right on you num pad\n", Console.ForegroundColor = ConsoleColor.Red);
                Console.ForegroundColor = ConsoleColor.White;
                DrawBoardArray();
                Console.WriteLine();
                Console.WriteLine("Press Space to start or escape to exit");

                if (Console.ReadKey(true).Key == ConsoleKey.Escape)
                {
                    Console.Clear();
                    OpenGameLobby();
                }
                else if (Console.ReadKey(true).Key != ConsoleKey.Spacebar)
                {
                    Console.Clear();
                    ExecuteGamePlay();
                }
                else
                {
                    while (true)
                    {
                        Console.Clear();
                        PrintWelcome();
                        grid[0, 0] = "[X]";

                        int row = 0;
                        int col = 0;
                        DrawBoardArray();

                        string[] flat = grid.Cast<string>().ToArray();
                        var arr = Enumerable.Range(0, 100).Where(i => flat[i] == "[$]").ToArray();

                        CreateNewGame();

                        access.UpdatePlayerPosition(1, 0);

                        Console.WriteLine("\n==================================");
                        Console.WriteLine($"Your position is: {access.PreviousPosition}");
                        Console.WriteLine("==================================");
                        Console.WriteLine();
                        Console.WriteLine("Press escape to exit");

                        for (var i = 0; i < Game.Length; i++)
                        {
                            ConsoleKey keyPressed;
                            do
                            {
                                ConsoleKeyInfo keyInfo = Console.ReadKey(true);
                                keyPressed = keyInfo.Key;

                                switch (keyPressed)
                                {
                                    case ConsoleKey.UpArrow:
                                        row--;
                                        if (i - 10 < 0 || row < 0)
                                        {
                                            row++;
                                            Console.WriteLine("You cant move here");
                                        }
                                        else
                                        {
                                            PrintWelcome();
                                            access.PreviousPosition = Game[i];
                                            i -= 10;
                                            access.NewPosition = Game[i];

                                            if (access.IsTileValid((int)access.NewPosition, access.GameNumber))
                                            {
                                                access.UpdatePlayerPosition((int)access.NewPosition, access.PreviousPosition);

                                                if (grid[row, col] == "[$]")
                                                {
                                                    Console.WriteLine("Wow");
                                                    Console.ReadLine();
                                                }

                                                grid[row, col] = "[X]";
                                                grid[row + 1, col] = "[ ]";
                                                DrawBoardArray();

                                                Console.WriteLine();
                                                Console.WriteLine("==================================");
                                                Console.WriteLine($"Your new position is: {access.NewPosition}");
                                                Console.WriteLine($"Your old position is: {access.PreviousPosition}");
                                                Console.WriteLine("==================================");
                                                Console.WriteLine();
                                                Console.WriteLine("Press escape to exit");
                                            }
                                            else
                                            {
                                                Console.WriteLine("You cant move here");
                                                i += 10;
                                                access.NewPosition = Game[i];

                                                grid[row, col] = "[X]";
                                                grid[row + 1, col] = "[ ]";

                                                DrawBoardArray();
                                                PrintPosition();
                                            }
                                        }
                                        break;

                                    case ConsoleKey.LeftArrow:
                                        col--;
                                        if (i == 0 || col < 0)
                                        {
                                            col++;
                                            Console.WriteLine("You cant move here");
                                        }
                                        else
                                        {
                                            PrintWelcome();
                                            access.PreviousPosition = Game[i];
                                            i--;
                                            access.NewPosition = Game[i];

                                            if (access.IsTileValid((int)access.NewPosition, access.GameNumber))
                                            {
                                                access.UpdatePlayerPosition((int)access.NewPosition, access.PreviousPosition);

                                                grid[row, col] = "[X]";
                                                grid[row, col + 1] = "[ ]";
                                                DrawBoardArray();

                                                Console.WriteLine();
                                                Console.WriteLine("==================================");
                                                Console.WriteLine($"Your new position is: {access.NewPosition}");
                                                Console.WriteLine($"Your old position is: {access.PreviousPosition}");
                                                Console.WriteLine("==================================");
                                                Console.WriteLine();
                                                Console.WriteLine("Press escape to exit");
                                            }
                                            else
                                            {
                                                Console.WriteLine("You cant move here");
                                                i++;
                                                access.NewPosition = Game[i];

                                                grid[row, col] = "[X]";
                                                grid[row + 1, col] = "[ ]";

                                                DrawBoardArray();
                                                PrintPosition();
                                            }
                                        }
                                        break;

                                    case ConsoleKey.DownArrow:
                                        row++;
                                        if (i + 10 > Game.Length || row == 10)
                                        {
                                            row--;
                                            access.NewPosition = Game[i];
                                            Console.WriteLine("You cant move here");
                                        }
                                        else
                                        {
                                            PrintWelcome();
                                            access.PreviousPosition = Game[i];
                                            i += 10;
                                            access.NewPosition = Game[i];

                                            if (access.IsTileValid((int)access.NewPosition, access.GameNumber))
                                            {
                                                access.UpdatePlayerPosition((int)access.NewPosition, access.PreviousPosition);
                                                if (access.NewPosition == 100)
                                                {
                                                    try
                                                    {
                                                        try
                                                        {
                                                            access.UpdatePlayerPosition((int)access.NewPosition, access.PreviousPosition);
                                                            grid[row, col] = "[ ]";
                                                            grid[row - 1, col] = "[ ]";
                                                        }
                                                        catch (Exception error)
                                                        {
                                                            Console.WriteLine(error);
                                                            Console.ReadLine();
                                                        }
                                                        Console.Clear();
                                                        Console.WriteLine("Congrats, you have finished the game");
                                                        Console.WriteLine("Press enter to continue");
                                                        Console.ReadLine();
                                                        try
                                                        {
                                                            OpenGameLobby();
                                                        }
                                                        catch (Exception error)
                                                        {
                                                            Console.WriteLine(error);
                                                            Console.ReadLine();
                                                        }
                                                    }
                                                    catch (Exception error)
                                                    {
                                                        Console.WriteLine(error);
                                                        Console.ReadLine();
                                                    }
                                                }
                                                else
                                                {
                                                    grid[row, col] = "[X]";
                                                    grid[row - 1, col] = "[ ]";
                                                    DrawBoardArray();
                                                    PrintPosition();
                                                }
                                            }
                                            else
                                            {
                                                Console.WriteLine("You cant move here");
                                                Console.ReadLine();
                                                i -= 10;
                                                access.NewPosition = Game[i];

                                                grid[row, col] = "[X]";
                                                grid[row + 1, col] = "[ ]";

                                                DrawBoardArray();
                                                PrintPosition();
                                            }
                                        }
                                        break;

                                    case ConsoleKey.RightArrow:
                                        col++;
                                        if (i == Game.Length - 1 || col == 10)
                                        {
                                            col--;
                                            Console.WriteLine("You cant move here");
                                        }
                                        else
                                        {
                                            PrintWelcome();
                                            access.PreviousPosition = Game[i];
                                            i++;
                                            access.NewPosition = Game[i];
                                            if (access.IsTileValid((int)access.NewPosition, access.GameNumber))
                                            {
                                                access.UpdatePlayerPosition((int)access.NewPosition, access.PreviousPosition);

                                                if (access.NewPosition == 100)
                                                {
                                                    try
                                                    {
                                                        access.UpdatePlayerPosition((int)access.NewPosition, access.PreviousPosition);
                                                        grid[row, col] = "[ ]";
                                                        grid[row, col - 1] = "[ ]";
                                                    }
                                                    catch (Exception error)
                                                    {
                                                        Console.WriteLine(error);
                                                        Console.ReadLine();
                                                    }
                                                    Console.Clear();
                                                    Console.WriteLine("Congrats, you have finished the game");
                                                    Console.WriteLine("Press enter to continue");
                                                    Console.ReadLine();
                                                    try
                                                    {
                                                        OpenGameLobby();
                                                    }
                                                    catch (Exception error)
                                                    {
                                                        Console.WriteLine(error);
                                                        Console.ReadLine();
                                                    }
                                                }
                                                else
                                                {
                                                    grid[row, col] = "[X]";
                                                    grid[row, col - 1] = "[ ]";
                                                    DrawBoardArray();

                                                    Console.WriteLine();
                                                    Console.WriteLine("==================================");
                                                    Console.WriteLine($"Your new position is: {access.NewPosition}");
                                                    Console.WriteLine($"Your old position is: {access.PreviousPosition}");
                                                    Console.WriteLine("==================================");
                                                    Console.WriteLine();
                                                    Console.WriteLine("Press escape to exit");
                                                }
                                            }
                                            else
                                            {
                                                Console.WriteLine("You cant move here");
                                                i--;
                                                access.NewPosition = Game[i];

                                                grid[row, col] = "[X]";
                                                grid[row + 1, col] = "[ ]";

                                                DrawBoardArray();
                                                PrintPosition();
                                            }
                                        }
                                        break;

                                    case ConsoleKey.Escape:
                                        Console.Clear();

                                        try
                                        {
                                            var pos = Enumerable.Range(0, 100).Where(x => flat[x] == "[X]").ToArray();

                                            access.SavePlayerPosition(username, pos[0], access.GameNumber);

                                            for (int l = 0; l < grid.GetLength(0); l++)
                                            {
                                                for (int j = 0; j < grid.GetLength(1); j++)
                                                {
                                                    grid[l, j] = "[ ]";
                                                }
                                                Console.WriteLine();
                                            }
                                        }
                                        catch (Exception error)
                                        {
                                            Console.WriteLine(error);
                                            Console.ReadLine();
                                        }

                                        OpenGameLobby();
                                        break;
                                }
                            } while (keyPressed != ConsoleKey.Enter);
                        }
                    }
                }
            }
            catch (Exception error)
            {
                Console.WriteLine(error);
                Console.ReadLine();
            }
        } //No

        public void PrintPosition()
        {
            Console.WriteLine();
            Console.WriteLine("==================================");
            Console.WriteLine($"Your new position is: {access.NewPosition}");
            Console.WriteLine($"Your old position is: {access.PreviousPosition}");
            Console.WriteLine("==================================");
            Console.WriteLine();
            Console.WriteLine("Press escape to exit");
        } //No

        public void PrintWelcome()
        {
            Console.Clear();
            Console.WriteLine("==================================");
            Console.WriteLine($"Welcome to the Dungeon");
            Console.WriteLine("==================================");
        } //No

        public void CheckSignUpFields(string username, string password, string email, MySqlCommand cmd)
        {
            if (username != "" && password != "" && email != "")
            {
                //Calls checkUsername to see if the username already exists in the system
                if (access.CheckUsername(username))
                {
                    Console.Clear();
                    Console.WriteLine("This Username Already Exists, Press Enter to try logging in");
                    Console.ReadLine();
                    access.Login(username, password);
                }
                else
                {
                    try
                    {
                        if (cmd.ExecuteNonQuery() == 1)
                        {
                            Console.WriteLine("Error");
                            Console.ReadLine();
                        }
                        else
                        {
                            Console.Clear();
                            access.SetUserLoginStatus(username);
                            OpenUserMenu();
                        }
                    }
                    catch (Exception error)
                    {
                        Console.WriteLine(error);
                    }
                }
            }
            else
            {
                Console.WriteLine("Please Enter all your details");
            }
        } //No

        public void CheckLoginFields(string username, string password, DataTable table)
        {
            if (username != "" || password != "")
            {
                if (table.Rows.Count > 0)
                {
                    try
                    {
                        Console.Clear();

                        if (access.CheckAccountStatus(username))
                        {
                            Console.WriteLine("Account is locked. To unlock account, please contact an admin at daniel-ewers2@live.nmit.ac.nz \n");
                            Console.WriteLine("Press Enter to Continue...");
                            Console.ReadLine();
                            OpenMainMenu();
                            return;
                        }
                        else
                        {
                            if (!access.CheckIfAdmin(username))
                            {
                                access.UserType = "Admin";
                                access.SetUserLoginStatus(username);
                                OpenAdminMenu();
                                Console.ReadLine();
                            }
                            else if (access.CheckIfAdmin(username))
                            {
                                access.UserType = "User";
                                access.SetUserLoginStatus(username);
                                Console.Clear();
                                OpenUserMenu();
                                Console.ReadLine();
                            }
                            else
                            {
                                Console.WriteLine("Critical Error");
                            }
                        }
                    }
                    catch (Exception error)
                    {
                        Console.WriteLine(error.Message);
                    }
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Username or Password is incorrect!");
                    Console.ReadLine();
                    access.SetFailedAttempt(username);
                    OpenMainMenu();
                }
            }
            else
            {
                Console.WriteLine("Please Enter all your details");
                Console.ReadLine();
                OpenMainMenu();
            }
        } //No
    }
}