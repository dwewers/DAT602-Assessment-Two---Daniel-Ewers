﻿namespace ConsoleGame
{
    public class UserData
    {
        private  string _user;
        private  string _password;
        private  string _email;
        private  string _gameMode;
        private  string _character;

        public  string User
        {
            get => _user; set => _user = value;
        }

        public  string Password
        {
            get => _password; set => _password = value;
        }

        public  string Email
        {
            get => _email; set => _email = value;
        }

        public  string GameMode
        {
            get => _gameMode; set => _gameMode = value;
        }

        public  string Character
        {
            get => _character; set => _character = value;
        }

        public UserData(string username, string password, string email, string gameMode, string chararacter)
        {
            User = username;
            Password = password;
            Email = email;
            GameMode = gameMode;
            Character = chararacter;
        }
    }
}